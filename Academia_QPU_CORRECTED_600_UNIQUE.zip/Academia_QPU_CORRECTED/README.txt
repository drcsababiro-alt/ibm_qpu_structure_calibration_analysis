Canonical input dataset only. 600 unique regions; 8 deterministic replacements.
No inferential output from the obsolete archive is carried forward.
Rerun ALL tests, including MI, CCA, RV, matched distance, overlap, using these corrected records.
